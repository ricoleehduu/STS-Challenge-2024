# ClassificationPredictor
---
:::ultralytics.yolo.v8.classify.predict.ClassificationPredictor
<br><br>

# predict
---
:::ultralytics.yolo.v8.classify.predict.predict
<br><br>
