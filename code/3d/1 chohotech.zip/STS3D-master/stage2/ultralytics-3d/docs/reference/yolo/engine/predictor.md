# BasePredictor
---
:::ultralytics.yolo.engine.predictor.BasePredictor
<br><br>
