# SegmentationPredictor
---
:::ultralytics.yolo.v8.segment.predict.SegmentationPredictor
<br><br>

# predict
---
:::ultralytics.yolo.v8.segment.predict.predict
<br><br>
