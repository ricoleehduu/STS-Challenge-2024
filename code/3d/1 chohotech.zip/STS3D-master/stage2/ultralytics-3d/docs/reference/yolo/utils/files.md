# WorkingDirectory
---
:::ultralytics.yolo.utils.files.WorkingDirectory
<br><br>

# increment_path
---
:::ultralytics.yolo.utils.files.increment_path
<br><br>

# file_age
---
:::ultralytics.yolo.utils.files.file_age
<br><br>

# file_date
---
:::ultralytics.yolo.utils.files.file_date
<br><br>

# file_size
---
:::ultralytics.yolo.utils.files.file_size
<br><br>

# get_latest_run
---
:::ultralytics.yolo.utils.files.get_latest_run
<br><br>
