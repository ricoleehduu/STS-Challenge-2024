# on_pretrain_routine_end
---
:::ultralytics.yolo.utils.callbacks.mlflow.on_pretrain_routine_end
<br><br>

# on_fit_epoch_end
---
:::ultralytics.yolo.utils.callbacks.mlflow.on_fit_epoch_end
<br><br>

# on_train_end
---
:::ultralytics.yolo.utils.callbacks.mlflow.on_train_end
<br><br>
