read monai for a simple 3D segmentation task, we provide dataset script
note that use boundary as weight for both bce loss and dice loss