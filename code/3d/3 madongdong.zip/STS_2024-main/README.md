## Hi, I’m @[STS-challenge](https://sts-challenge.github.io/)👋

This repository provides the evaluation code, submission instruction and baselines of the STS Challenges. More details are available on the corresponding websites.
# STS_2024
