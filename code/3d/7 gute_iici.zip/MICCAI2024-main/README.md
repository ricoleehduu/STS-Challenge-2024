# MICCAI2024



## first:
  run `process.ipynb` => process the data 


## second:
  run `bash train_bin.sh` to get the weight of binary segmentation

## three:
  run  `add_roi_mask.ipynb` to add binary mask

## last:
  run `bash train_multitask.sh` to get weight of instance segmentation

# Acknowledgement
![logo](https://github.com/user-attachments/assets/90ce9a87-7ae3-4652-a3f9-59f0a3c2dda6)
