#!/bin/bash

set -e

#echo "hello world"
python run_inference.py


