python train_STS.py
