python test_STS.py
