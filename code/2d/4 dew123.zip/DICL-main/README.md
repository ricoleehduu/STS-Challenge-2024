##Train
get into ./code and run train.sh
