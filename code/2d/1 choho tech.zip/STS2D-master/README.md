Read Ultralytics docs for details

Labels for unlabeled dataset are saved in `labels`. If needed, contact STS organizers for original dataset.

`expperiments/train_model` for training model on all data
`expperiments/finetune_model` for fine-tuning labeled data 