All task Predictors are inherited from `BasePredictors` class that contains the model validation routine boilerplate.
You can override any function of these Trainers to suit your needs.

---

### BasePredictor API Reference

:::ultralytics.yolo.engine.predictor.BasePredictor