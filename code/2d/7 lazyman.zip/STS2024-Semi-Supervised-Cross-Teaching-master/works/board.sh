export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION="python"
tensorboard --logdir=snapshots/log
